<?php
namespace Sweetcore;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Sweetcore Utils class
 *
 *
 * @since 1.6.0
 */
class Utils {


}
